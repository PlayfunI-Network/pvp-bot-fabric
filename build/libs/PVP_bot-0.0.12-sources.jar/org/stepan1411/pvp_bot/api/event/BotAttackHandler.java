package org.stepan1411.pvp_bot.api.event;

import net.minecraft.class_1297;
import net.minecraft.class_3222;

/**
 * Handler for bot attack events
 */
@FunctionalInterface
public interface BotAttackHandler {
    /**
     * Called when a bot attacks an entity
     * @param bot The bot that attacks
     * @param target The target entity
     * @return true to cancel the attack
     */
    boolean onBotAttack(class_3222 bot, class_1297 target);
}
