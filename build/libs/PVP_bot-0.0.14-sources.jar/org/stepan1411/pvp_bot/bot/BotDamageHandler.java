package org.stepan1411.pvp_bot.bot;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1297;
import net.minecraft.class_3222;

public class BotDamageHandler {
    
    public static void register() {

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {

            if (entity instanceof class_3222 player) {
                String playerName = player.method_5477().getString();
                

                if (BotManager.getAllBots().contains(playerName)) {

                    try {
                        class_1297 attacker = source.method_5529();
                        boolean cancelled = org.stepan1411.pvp_bot.api.BotAPIIntegration.fireDamageEvent(player, attacker, amount);
                        if (cancelled) {
                            return false;
                        }
                    } catch (Exception e) {
                        System.err.println("[PVP_BOT_API] Error firing damage event: " + e.getMessage());
                    }
                    

                    BotCombat.onBotDamaged(player, source);
                }
            }
            

            return true;
        });
    }
}
