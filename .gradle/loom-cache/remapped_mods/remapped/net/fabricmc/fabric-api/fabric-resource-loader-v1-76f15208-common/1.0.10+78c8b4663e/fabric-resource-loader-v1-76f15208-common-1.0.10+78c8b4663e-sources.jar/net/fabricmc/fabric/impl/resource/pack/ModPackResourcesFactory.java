/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.resource.pack;

import java.util.ArrayList;
import net.fabricmc.fabric.api.resource.v1.pack.ModPackResources;
import net.minecraft.resource.OverlayResourcePack;
import net.minecraft.resource.ResourcePack;
import net.minecraft.resource.ResourcePackInfo;
import net.minecraft.resource.ResourcePackProfile;

public record ModPackResourcesFactory(ModPackResources pack) implements ResourcePackProfile.PackFactory {
	@Override
	public ResourcePack open(ResourcePackInfo location) {
		return this.pack;
	}

	@Override
	public ResourcePack openWithOverlays(ResourcePackInfo location, ResourcePackProfile.Metadata metadata) {
		if (metadata.overlays().isEmpty()) {
			return this.pack;
		} else {
			var overlays = new ArrayList<ResourcePack>(metadata.overlays().size());

			for (String overlay : metadata.overlays()) {
				overlays.add(this.pack.createOverlay(overlay));
			}

			return new OverlayResourcePack(this.pack, overlays);
		}
	}
}
