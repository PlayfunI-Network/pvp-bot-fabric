/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.renderer.client.item;

import com.llamalad7.mixinextras.sugar.Local;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.fabric.api.renderer.v1.mesh.Mesh;
import net.fabricmc.fabric.impl.renderer.BasicItemModelExtension;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.BlockRenderLayer;
import net.minecraft.client.render.BlockRenderLayers;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.item.model.BasicItemModel;
import net.minecraft.client.render.item.model.ItemModel;
import net.minecraft.client.render.model.ErrorCollectingSpriteGetter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.HeldItemContext;

@Mixin(BasicItemModel.class)
abstract class BlockModelWrapperMixin implements ItemModel, BasicItemModelExtension {
	@Shadow
	@Final
	@Mutable
	private boolean animated;

	@Unique
	@Nullable
	private Mesh mesh;

	@Inject(method = "update", at = @At("RETURN"))
	private void onReturnUpdate(final ItemRenderState output, final ItemStack item, final ItemModelManager resolver, final ItemDisplayContext displayContext, final @Nullable ClientWorld level, final @Nullable HeldItemContext owner, final int seed, CallbackInfo ci, @Local ItemRenderState.LayerRenderState layer) {
		if (mesh != null) {
			// This logic matches that of ITEM_RENDER_TYPE_GETTER and BLOCK_RENDER_TYPE_GETTER
			BlockRenderLayer defaultSectionLayer;

			if (item.getItem() instanceof BlockItem blockItem) {
				defaultSectionLayer = BlockRenderLayers.getBlockLayer(blockItem.getBlock().getDefaultState());
			} else {
				defaultSectionLayer = BlockRenderLayer.TRANSLUCENT;
			}

			layer.setRenderTypeGetter((quadAtlas, sectionLayer) -> {
				return switch (quadAtlas) {
				case BLOCK -> {
					if (sectionLayer == null) {
						sectionLayer = defaultSectionLayer;
					}

					if (sectionLayer != class_11515.field_60926) {
						yield class_4722.method_24074();
					}

					yield class_4722.method_76545();
				}
				case ITEM -> class_4722.method_29382();
				};
			});

			mesh.outputTo(layer.emitter());
		}
	}

	@Override
	public void fabric_setMesh(Mesh mesh, ErrorCollectingSpriteGetter spriteGetter) {
		this.mesh = mesh;

		if (!animated) {
			mesh.forEach(quad -> {
				if (animated) {
					return;
				}

				ItemRenderState.Glint glint = quad.glint();

				if ((glint != null && glint != ItemRenderState.Glint.NONE)
						|| spriteGetter.spriteFinder(quad.atlas().getTextureId()).find(quad).method_45851().method_73020()) {
					animated = true;
				}
			});
		}
	}
}
