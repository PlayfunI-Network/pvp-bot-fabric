package org.stepan1411.pvp_bot.bot.pathfinding;

import java.util.*;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;


public class AStarPathfinder {
    
    private static final int MAX_ITERATIONS = 15000;
    private static final int MAX_PATH_LENGTH = 1000;
    
    
    public static List<class_243> findPath(class_3222 bot, class_243 targetPos) {
        class_1937 world = bot.method_51469();
        class_2338 start = bot.method_24515();
        class_2338 goal = class_2338.method_49638(targetPos);
        

        if (!isValidPosition(world, goal)) {
            goal = findNearestValid(world, goal, 5);
            if (goal == null) {
                return null;
            }
        }
        
        return calculatePath(world, start, goal);
    }
    
    
    private static List<class_243> calculatePath(class_1937 world, class_2338 start, class_2338 goal) {
        MovementCalculator movementCalc = new MovementCalculator(world);
        

        PriorityQueue<PathNode> openSet = new PriorityQueue<>();
        Map<Long, PathNode> allNodes = new HashMap<>();
        Set<Long> closedSet = new HashSet<>();
        

        PathNode startNode = new PathNode(start, null, 0, heuristic(start, goal));
        openSet.add(startNode);
        allNodes.put(startNode.hash, startNode);
        
        int iterations = 0;
        PathNode bestNode = startNode;
        
        while (!openSet.isEmpty() && iterations < MAX_ITERATIONS) {
            iterations++;
            
            PathNode current = openSet.poll();
            

            if (current.estimatedCost < bestNode.estimatedCost) {
                bestNode = current;
            }
            

            if (isInGoal(current.pos, goal)) {
                return reconstructPath(current);
            }
            
            closedSet.add(current.hash);
            

            List<MovementCalculator.PossibleMovement> movements = movementCalc.getMovements(current.pos);
            
            for (MovementCalculator.PossibleMovement movement : movements) {
                class_2338 neighborPos = movement.destination;
                long neighborHash = neighborPos.method_10063();
                
                if (closedSet.contains(neighborHash)) {
                    continue;
                }
                
                double tentativeCost = current.cost + movement.cost;
                PathNode neighborNode = allNodes.get(neighborHash);
                
                if (neighborNode == null) {

                    neighborNode = new PathNode(neighborPos, current, tentativeCost, heuristic(neighborPos, goal));
                    allNodes.put(neighborHash, neighborNode);
                    openSet.add(neighborNode);
                } else if (tentativeCost < neighborNode.cost) {

                    openSet.remove(neighborNode);
                    neighborNode.parent = current;
                    neighborNode.cost = tentativeCost;
                    neighborNode.combinedCost = tentativeCost + neighborNode.estimatedCost;
                    openSet.add(neighborNode);
                }
            }
        }
        

        if (bestNode != startNode && bestNode.pos.method_19771(goal, 10.0)) {
            return reconstructPath(bestNode);
        }
        
        return null;
    }
    
    
    private static boolean isInGoal(class_2338 pos, class_2338 goal) {
        return pos.method_19771(goal, 2.0);
    }
    
    
    private static double heuristic(class_2338 from, class_2338 to) {
        int dx = to.method_10263() - from.method_10263();
        int dy = to.method_10264() - from.method_10264();
        int dz = to.method_10260() - from.method_10260();
        return Math.sqrt(dx * dx + dy * dy + dz * dz) * MovementCalculator.WALK_ONE_BLOCK_COST;
    }
    
    
    private static List<class_243> reconstructPath(PathNode goal) {
        List<class_243> path = new ArrayList<>();
        PathNode current = goal;
        
        while (current != null && path.size() < MAX_PATH_LENGTH) {
            path.add(new class_243(
                current.pos.method_10263() + 0.5,
                current.pos.method_10264() + 0.1,
                current.pos.method_10260() + 0.5
            ));
            current = current.parent;
        }
        
        Collections.reverse(path);
        return simplifyPath(path);
    }
    
    
    private static List<class_243> simplifyPath(List<class_243> path) {
        if (path.size() <= 2) {
            return path;
        }
        
        List<class_243> simplified = new ArrayList<>();
        simplified.add(path.get(0));
        
        for (int i = 1; i < path.size() - 1; i++) {
            class_243 prev = path.get(i - 1);
            class_243 current = path.get(i);
            class_243 next = path.get(i + 1);
            

            class_243 dir1 = current.method_1020(prev).method_1029();
            class_243 dir2 = next.method_1020(current).method_1029();
            double dot = dir1.method_1026(dir2);
            
            if (dot < 0.95) {
                simplified.add(current);
            }
        }
        
        simplified.add(path.get(path.size() - 1));
        return simplified;
    }
    
    
    private static boolean isValidPosition(class_1937 world, class_2338 pos) {
        return world.method_8320(pos).method_26215() || world.method_8320(pos).method_51176();
    }
    
    
    private static class_2338 findNearestValid(class_1937 world, class_2338 target, int maxRadius) {
        for (int radius = 1; radius <= maxRadius; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    for (int dy = -2; dy <= 2; dy++) {
                        class_2338 candidate = target.method_10069(dx, dy, dz);
                        if (isValidPosition(world, candidate)) {
                            return candidate;
                        }
                    }
                }
            }
        }
        return null;
    }
}
