package org.stepan1411.pvp_bot.gui;

import eu.pb4.sgui.api.elements.GuiElementBuilder;
import eu.pb4.sgui.api.gui.SimpleGui;
import org.stepan1411.pvp_bot.bot.BotSettings;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;

public class SettingsGui extends SimpleGui {
    
    private int currentPage = 0;
    private final List<SettingEntry> allSettings = new ArrayList<>();
    private static final int SETTINGS_PER_PAGE = 45; // 5 СЂСЏРґРѕРІ РїРѕ 9 СЃР»РѕС‚РѕРІ
    
    public SettingsGui(class_3222 player) {
        super(class_3917.field_17327, player, false);
        this.setTitle(class_2561.method_43470("PVP Bot Settings"));
        
        initializeSettings();
        updatePage();
    }
    
    private void initializeSettings() {
        BotSettings s = BotSettings.get();
        
        // === Equipment Settings ===
        allSettings.add(new SettingEntry(
            "Auto Armor",
            "Automatically equip best armor",
            s::isAutoEquipArmor,
            s::setAutoEquipArmor
        ));
        
        allSettings.add(new SettingEntry(
            "Auto Weapon",
            "Automatically equip best weapon",
            s::isAutoEquipWeapon,
            s::setAutoEquipWeapon
        ));
        
        allSettings.add(new SettingEntry(
            "Auto Totem",
            "Auto-equip totem in offhand",
            s::isAutoTotemEnabled,
            s::setAutoTotemEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Auto Shield",
            "Auto-use shield when blocking",
            s::isAutoShieldEnabled,
            s::setAutoShieldEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Shield Break",
            "Switch to axe to break enemy shield",
            s::isShieldBreakEnabled,
            s::setShieldBreakEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Prefer Sword",
            "Prefer sword over axe",
            s::isPreferSword,
            s::setPreferSword
        ));
        
        allSettings.add(new SettingEntry(
            "Drop Worse Armor",
            "Drop worse armor pieces",
            s::isDropWorseArmor,
            s::setDropWorseArmor
        ));
        
        allSettings.add(new SettingEntry(
            "Drop Worse Weapons",
            "Drop worse weapons",
            s::isDropWorseWeapons,
            s::setDropWorseWeapons
        ));
        
        // === Combat Settings ===
        allSettings.add(new SettingEntry(
            "Combat",
            "Enable/disable combat system",
            s::isCombatEnabled,
            s::setCombatEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Revenge",
            "Attack entities that damage the bot",
            s::isRevengeEnabled,
            s::setRevengeEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Auto Target",
            "Automatically search for enemies",
            s::isAutoTargetEnabled,
            s::setAutoTargetEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Target Players",
            "Can target players",
            s::isTargetPlayers,
            s::setTargetPlayers
        ));
        
        allSettings.add(new SettingEntry(
            "Target Mobs",
            "Can target hostile mobs",
            s::isTargetHostileMobs,
            s::setTargetHostileMobs
        ));
        
        allSettings.add(new SettingEntry(
            "Target Bots",
            "Can target other bots",
            s::isTargetOtherBots,
            s::setTargetOtherBots
        ));
        
        allSettings.add(new SettingEntry(
            "Criticals",
            "Perform critical hits",
            s::isCriticalsEnabled,
            s::setCriticalsEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Ranged",
            "Use bows/crossbows",
            s::isRangedEnabled,
            s::setRangedEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Mace",
            "Use mace with wind charges",
            s::isMaceEnabled,
            s::setMaceEnabled
        ));
        
        // === Utilities ===
        allSettings.add(new SettingEntry(
            "Auto Potion",
            "Auto-use healing/buff potions",
            s::isAutoPotionEnabled,
            s::setAutoPotionEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Auto Eat",
            "Auto-eat when hungry",
            s::isAutoEatEnabled,
            s::setAutoEatEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Cobweb",
            "Use cobwebs to slow enemies",
            s::isCobwebEnabled,
            s::setCobwebEnabled
        ));
        
        // === Navigation ===
        allSettings.add(new SettingEntry(
            "Retreat",
            "Retreat when low HP",
            s::isRetreatEnabled,
            s::setRetreatEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Bunny Hop",
            "Jump while running",
            s::isBhopEnabled,
            s::setBhopEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Idle Wander",
            "Wander when no target",
            s::isIdleWanderEnabled,
            s::setIdleWanderEnabled
        ));
        
        // === Factions ===
        allSettings.add(new SettingEntry(
            "Factions",
            "Enable faction system",
            s::isFactionsEnabled,
            s::setFactionsEnabled
        ));
        
        allSettings.add(new SettingEntry(
            "Friendly Fire",
            "Allow damage to allies",
            s::isFriendlyFireEnabled,
            s::setFriendlyFireEnabled
        ));
    }
    
    private void updatePage() {
        // РћС‡РёС‰Р°РµРј GUI
        for (int i = 0; i < this.getSize(); i++) {
            this.clearSlot(i);
        }
        
        // Р’С‹С‡РёСЃР»СЏРµРј РґРёР°РїР°Р·РѕРЅ РЅР°СЃС‚СЂРѕРµРє РґР»СЏ С‚РµРєСѓС‰РµР№ СЃС‚СЂР°РЅРёС†С‹
        int startIndex = currentPage * SETTINGS_PER_PAGE;
        int endIndex = Math.min(startIndex + SETTINGS_PER_PAGE, allSettings.size());
        
        // Р”РѕР±Р°РІР»СЏРµРј РЅР°СЃС‚СЂРѕР№РєРё
        for (int i = startIndex; i < endIndex; i++) {
            SettingEntry setting = allSettings.get(i);
            int slot = i - startIndex;
            
            boolean currentValue = setting.getter.get();
            
            GuiElementBuilder element = new GuiElementBuilder()
                .setItem(currentValue ? class_1802.field_8120 : class_1802.field_8197)
                .setName(class_2561.method_43470(setting.name).method_27692(currentValue ? class_124.field_1060 : class_124.field_1061))
                .addLoreLine(class_2561.method_43470(setting.description).method_27692(class_124.field_1080))
                .addLoreLine(class_2561.method_43470(""))
                .addLoreLine(class_2561.method_43470("Status: " + (currentValue ? "Enabled" : "Disabled"))
                    .method_27692(currentValue ? class_124.field_1060 : class_124.field_1061))
                .addLoreLine(class_2561.method_43470("Click to toggle").method_27692(class_124.field_1054))
                .setCallback((index, type, action) -> {
                    setting.setter.accept(!currentValue);
                    updatePage();
                });
            
            this.setSlot(slot, element);
        }
        
        // Р”РѕР±Р°РІР»СЏРµРј РЅР°РІРёРіР°С†РёСЋ РІРЅРёР·Сѓ (РїРѕСЃР»РµРґРЅРёР№ СЂСЏРґ)
        int totalPages = (int) Math.ceil((double) allSettings.size() / SETTINGS_PER_PAGE);
        
        // РџСЂРµРґС‹РґСѓС‰Р°СЏ СЃС‚СЂР°РЅРёС†Р° (СЃР»РѕС‚ 45)
        if (currentPage > 0) {
            this.setSlot(45, new GuiElementBuilder()
                .setItem(class_1802.field_8236)
                .setName(class_2561.method_43470("Previous Page").method_27692(class_124.field_1054))
                .addLoreLine(class_2561.method_43470("Page " + currentPage + "/" + totalPages).method_27692(class_124.field_1080))
                .setCallback((index, type, action) -> {
                    currentPage--;
                    updatePage();
                })
            );
        }
        
        // РРЅС„РѕСЂРјР°С†РёСЏ Рѕ СЃС‚СЂР°РЅРёС†Рµ (СЃР»РѕС‚ 49 - С†РµРЅС‚СЂ)
        this.setSlot(49, new GuiElementBuilder()
            .setItem(class_1802.field_8529)
            .setName(class_2561.method_43470("Page " + (currentPage + 1) + "/" + totalPages).method_27692(class_124.field_1065))
            .addLoreLine(class_2561.method_43470("Settings: " + allSettings.size()).method_27692(class_124.field_1080))
        );
        
        // РЎР»РµРґСѓСЋС‰Р°СЏ СЃС‚СЂР°РЅРёС†Р° (СЃР»РѕС‚ 53)
        if (currentPage < totalPages - 1) {
            this.setSlot(53, new GuiElementBuilder()
                .setItem(class_1802.field_8236)
                .setName(class_2561.method_43470("Next Page").method_27692(class_124.field_1054))
                .addLoreLine(class_2561.method_43470("Page " + (currentPage + 2) + "/" + totalPages).method_27692(class_124.field_1080))
                .setCallback((index, type, action) -> {
                    currentPage++;
                    updatePage();
                })
            );
        }
        
        // РљРЅРѕРїРєР° РЅР°Р·Р°Рґ РІ РіР»Р°РІРЅРѕРµ РјРµРЅСЋ (СЃР»РѕС‚ 46)
        this.setSlot(46, new GuiElementBuilder()
            .setItem(class_1802.field_8107)
            .setName(class_2561.method_43470("Back to Menu").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                this.close();
                BotMenuGui.openMainMenu(this.player);
            })
        );
    }
    
    private static class SettingEntry {
        final String name;
        final String description;
        final BooleanGetter getter;
        final BooleanSetter setter;
        
        SettingEntry(String name, String description, BooleanGetter getter, BooleanSetter setter) {
            this.name = name;
            this.description = description;
            this.getter = getter;
            this.setter = setter;
        }
    }
    
    @FunctionalInterface
    interface BooleanGetter {
        boolean get();
    }
    
    @FunctionalInterface
    interface BooleanSetter {
        void accept(boolean value);
    }
}
